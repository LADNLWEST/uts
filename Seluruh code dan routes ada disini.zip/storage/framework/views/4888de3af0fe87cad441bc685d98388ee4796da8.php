<h1>Contact</h1>

<h1>Store address:</h1>
<br>
<h3>Jalan Pembangunan Baru Raya, </h3>
<br>
<h3>Kompleks Pertokoan Emerald Blok III/12 </h3>
<br>
<h3>Bintaro, Tangerang Selatan </h3>
<br>
<h3>Indonesia </h3>
<br>

<h1>Open Daily:</h1>
<br>
<h3>08.00-20.00 </h3>
<br>

<h1>Contact:</h1>
<br>
<h3>Phone : 021-0889776655 </h3>
<br>
<h3>Email : happybookstore@happy.com </h3>

<?php /**PATH C:\xampp\htdocs\Uts\resources\views/Contact.blade.php ENDPATH**/ ?>