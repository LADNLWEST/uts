


<?php $__env->startSection('judul', 'Happy BookStore'); ?>

<?php $__env->startSection('content'); ?>

<h1>Book Shelf<span class="badge badge-secondary">New</span></h1>
<div class="container">
<div class="row">
    <?php $__currentLoopData = $Book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4 mt-2">
        <div class="card" style="height:100%;">
            <img src="<?php echo e($b['Image']); ?>" class="card-img-top" alt="Image"> 
            
            <div class="card-body" >
              <p class="card-title" style="font-size:25px;"><?php echo e($b['Name']); ?></p>
              <h3>By<h3>
              <p class="card-text"><?php echo e($b['Author']); ?></p>
              <a class= "btn" href="">Detail</a>


              <!-- <p class="card-text">Synopsis : <?php echo e($b['Synopsis']); ?></p> -->
              <!-- <p class="card-text">Year : <?php echo e($b['Year']); ?></p> -->
              
              
              
            

             
            </div>
        
       </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('background', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Uts\resources\views/home.blade.php ENDPATH**/ ?>