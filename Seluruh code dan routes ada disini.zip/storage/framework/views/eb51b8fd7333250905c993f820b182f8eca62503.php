


<?php $__env->startSection('judul', 'Happy BookStore'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
<div class="row">
    <?php $__currentLoopData = $Publisher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="body" >
              <p class="title" style="font-size:25px;"><?php echo e($p['Name']); ?></p>
              <p class="text">Address :<?php echo e($p['Address']); ?></p>
              <p class="text">Phone : <?php echo e($p['Phone']); ?></p>
              <p class="text">Email : <?php echo e($p['Email']); ?></p>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
       </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('background', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Uts\resources\views/publish.blade.php ENDPATH**/ ?>