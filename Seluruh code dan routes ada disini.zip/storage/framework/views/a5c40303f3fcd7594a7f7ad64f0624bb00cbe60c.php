<div class="container text-center" style="background-color:blue; height:95px; width:16000px">
    <br>
    <p class="text-white" style="font-size:10px;">Happy Book Store</p>
    <p class="text-white" style="font-size:10px;">Copyright ©2022  </p>
    <br>
</div><?php /**PATH C:\xampp\htdocs\Uts\resources\views/footer.blade.php ENDPATH**/ ?>