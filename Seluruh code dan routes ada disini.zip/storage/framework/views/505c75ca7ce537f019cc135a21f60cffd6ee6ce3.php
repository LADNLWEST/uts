


<?php $__env->startSection('judul', 'Happy BookStore'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
<div class="row">
    <?php $__currentLoopData = $Book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<img src="<?php echo e($b['Image']); ?>" class="rounded mx-auto d-block" alt="Image"> 
<div class="body" >
              <p class="title" style="font-size:25px;"><?php echo e($b['Name']); ?></p>
              <p class="text">Author :<?php echo e($b['Author']); ?></p>
              <p class="text">Publisher : <?php echo e($b['Year']); ?></p>
              <p class="text">Year : <?php echo e($b['Year']); ?></p>
              <p class="text">Synopsis : <?php echo e($b['Synopsis']); ?></p> 
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
       </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('background', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Uts\resources\views/bookDetail.blade.php ENDPATH**/ ?>