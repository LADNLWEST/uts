<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index(){
       $Book = [
            [
               'Name'     => 'Bumi',
               'Image'    => 'https://upload.wikimedia.org/wikipedia/id/4/49/Bumi_%28sampul%29.jpg',
               'Year'     => '2014',
               'Author'   => 'Tere Liye',
               'Synopsis' => 'Novel ini mengisahkan tentang petualangan 3 remaja yang berusia 15 tahun bernama Raib, Ali dan Seli. Namun mereka bukanlah remaja biasa, melainkan remaja yang memiliki kekuatan khusus seperti Raib yang bisa menghilang, Seli yang bisa mengeluarkan petir dan Ali seorang pelajar yang sangat jenius.'
            ],
            [
                'Name'    => 'KKN di Desa Penari',
                'Image'   => 'https://upload.wikimedia.org/wikipedia/id/5/50/KKN_di_Desa_Penari_%28sampul%29.jpg',
                'Year'    => '2019',
                'Author'  => 'Simpleman',
                'Synopsis' => 'Enam mahasiswa diteror penari misterius saat menjalankan program kuliah kerja nyata di desa terpencil. Ternyata, salah satu dari mereka melanggar peraturan paling fatal di desa tersebut.'
            ],
            [
               'Name'     => 'Komet',
               'Image'    => 'https://upload.wikimedia.org/wikipedia/id/d/d4/Komet%28sampul%29.jpeg',
               'Year'     => '2018',
               'Author'   => 'Tere Liye',
               'Synopsis' => 'Tiga sahabat yang berpetualang bersama dengan tujuan untuk menyelamatkan dunia pararel dari musuh besar mereka, yaitu si Tanpa Mahkota. Setelah si Tanpa Mahkota lolos di akhir buku "Bintang" ia mencari dimana letak klan komet untuk meningkatkan kekuatannya.'
            ],
            [
               'Name'     => 'Bintang',
               'Image'    => 'https://upload.wikimedia.org/wikipedia/id/9/97/Sampul_novel_Bintang.jpeg',
               'Year'     => '2017',
               'Author'  => 'Tere Liye',
               'Synopsis' => 'Raib, Seli dan Ali meneruskan petualangan mereka. Mereka harus menemukan pasak bumi yang akan di runtuh kan oleh sekretaris Dewan kota. Oleh karna itu, Raib, Seli dan Ali melibatkan orang-orang yang berasal dari klan Bulan dan Matahari. Petualangan kali ini dibantu oleh Miss Selena sebagai pemimpin rombongan, juga 10 anggota pasukan bayangan dan pasukan matahari.Dengan 4 pesawat kapsul, mereka keluar masuk ke lorong kuno yang satu, ke lorong kuno berikutnya untuk mengecek kemungkinan disitu letak pasak bumi yang mereka cari. Semua berkat kecerdasan Ali dalam menganalisa kemungkinan dimana letaknya pasak bumi. Ada saja halangan dalam perjalanan mereka. Kapsul mereka hampir saja dihancurkan diruang padang sampah, yang untungnya diruang itu pula kapsul ‘’lly” yang ditumpangi Ali , Raib dan Seli di modifikasi agar menjadi pesawat yang lebih tangguh. Namun, ternyata letak pasak bumi bukan dari yang mereka perkirakan, tempat yang tidak pernah terfikir sebelumnya. Disaat sudah menemukan pasaknya, mereka dihadapkan oleh pilihan yang sulit. Dibawah pasak bumi terdapat “Penjara Bayangan” yang didalamnya terdapat musuh-musuh besar dari semua klan, dan menunggu untuk dibebaskan.Akhirnya mereka membiarkannya melepas sedikit demi sedikit sehingga aliran magma keluar sedikit demi sedikit dari pasak bumi namun lancar. Namun siapa sangka, mereka juga membebaskan musuh mereka yang sebenarnya, Si Tanpa Mahkota telah bebas.'
            ],
            [
               'Name'     => 'Selena',
               'Image'    => 'https://upload.wikimedia.org/wikipedia/id/e/e8/Selena_sampul.jpeg',
               'Year'     => '2020',
               'Author'  => 'Tere Liye',
               'Synopsis' => 'Buku Selena berlatar di Klan Bulan, menceritakan sosok Selena guru matematika Raib, Seli, dan Ali di Klan Bumi. Kisahnya dimulai saat Selena berusia 15 tahun, menjadi anak yatim piatu karena Ayahnya meninggal, dan kemudian menyusul ibunya, hidup miskin dan tinggal di Distrik Sabit Enam.'
            ],
            [
                'Name'    => 'Autumn in Paris',
                'Image'   => 'https://upload.wikimedia.org/wikipedia/id/6/6b/Autumn_in_Paris.jpg',
                'Year'    => '2007',
                'Author'  => 'Ilana Tan',
                'Synopsis' => 'Tara Dupont menyukai Paris dan musim gugur. Ia mengira sudah memiliki segalanya dalam hidup… sampai ia bertemu Tatsuya Fujisawa yang susah ditebak dan selalu membangkitkan rasa penasarannya sejak awal.

                Tatsuya Fujisawa benci Paris dan musim gugur. Ia datang ke Paris untuk mencari orang yang menghancurkan hidupnya. Namun ia tidak menduga akan terpesona pada Tara Dupont, gadis yang cerewet tapi bisa menenangkan jiwa dan pikirannya… juga mengubah dunianya.
                
                Tara maupun Tatsuya sama sekali tidak menyadari benang yang menghubungkan mereka dengan masa lalu, adanya rahasia yang menghancurkan segala harapan, perasaan, dan keyakinan. Ketika kebenaran terungkap, tersingkap pula arti putus asa… arti tak berdaya… Kenyataan juga begitu menyakitkan hingga mendorong salah satu dari mereka ingin mengakhiri hidup...'
            ]
            
       
         ];
         return view('home', compact('Book'));
    
    
    }

    public function index2(){
        $Book = [
            [
               'Name'     => 'Bumi',
               'Image'    => 'https://upload.wikimedia.org/wikipedia/id/4/49/Bumi_%28sampul%29.jpg',
               'Year'     => '2014',
               'Publisher'=> 'Penerbit A',
               'Author'   => 'Tere Liye',
               'Synopsis' => 'Novel ini mengisahkan tentang petualangan 3 remaja yang berusia 15 tahun bernama Raib, Ali dan Seli. Namun mereka bukanlah remaja biasa, melainkan remaja yang memiliki kekuatan khusus seperti Raib yang bisa menghilang, Seli yang bisa mengeluarkan petir dan Ali seorang pelajar yang sangat jenius.'
            ],
            [
                'Name'    => 'KKN di Desa Penari',
                'Image'   => 'https://upload.wikimedia.org/wikipedia/id/5/50/KKN_di_Desa_Penari_%28sampul%29.jpg',
                'Year'    => '2019',
                'Publisher'=> 'Penerbit B',
                'Author'  => 'Simpleman',
                'Synopsis' => 'Enam mahasiswa diteror penari misterius saat menjalankan program kuliah kerja nyata di desa terpencil. Ternyata, salah satu dari mereka melanggar peraturan paling fatal di desa tersebut.'
            ],
            [
               'Name'     => 'Komet',
               'Image'    => 'https://upload.wikimedia.org/wikipedia/id/d/d4/Komet%28sampul%29.jpeg',
               'Year'     => '2018',
               'Publisher'=> 'Penerbit A',
               'Author'   => 'Tere Liye',
               'Synopsis' => 'Tiga sahabat yang berpetualang bersama dengan tujuan untuk menyelamatkan dunia pararel dari musuh besar mereka, yaitu si Tanpa Mahkota. Setelah si Tanpa Mahkota lolos di akhir buku "Bintang" ia mencari dimana letak klan komet untuk meningkatkan kekuatannya.'
            ],
            [
               'Name'     => 'Bintang',
               'Image'    => 'https://upload.wikimedia.org/wikipedia/id/9/97/Sampul_novel_Bintang.jpeg',
               'Year'     => '2017',
               'Publisher'=> 'Penerbit A',
               'Author'  => 'Tere Liye',
               'Synopsis' => 'Raib, Seli dan Ali meneruskan petualangan mereka. Mereka harus menemukan pasak bumi yang akan di runtuh kan oleh sekretaris Dewan kota. Oleh karna itu, Raib, Seli dan Ali melibatkan orang-orang yang berasal dari klan Bulan dan Matahari. Petualangan kali ini dibantu oleh Miss Selena sebagai pemimpin rombongan, juga 10 anggota pasukan bayangan dan pasukan matahari.Dengan 4 pesawat kapsul, mereka keluar masuk ke lorong kuno yang satu, ke lorong kuno berikutnya untuk mengecek kemungkinan disitu letak pasak bumi yang mereka cari. Semua berkat kecerdasan Ali dalam menganalisa kemungkinan dimana letaknya pasak bumi. Ada saja halangan dalam perjalanan mereka. Kapsul mereka hampir saja dihancurkan diruang padang sampah, yang untungnya diruang itu pula kapsul ‘’lly” yang ditumpangi Ali , Raib dan Seli di modifikasi agar menjadi pesawat yang lebih tangguh. Namun, ternyata letak pasak bumi bukan dari yang mereka perkirakan, tempat yang tidak pernah terfikir sebelumnya. Disaat sudah menemukan pasaknya, mereka dihadapkan oleh pilihan yang sulit. Dibawah pasak bumi terdapat “Penjara Bayangan” yang didalamnya terdapat musuh-musuh besar dari semua klan, dan menunggu untuk dibebaskan.Akhirnya mereka membiarkannya melepas sedikit demi sedikit sehingga aliran magma keluar sedikit demi sedikit dari pasak bumi namun lancar. Namun siapa sangka, mereka juga membebaskan musuh mereka yang sebenarnya, Si Tanpa Mahkota telah bebas.'
            ],
            [
               'Name'     => 'Selena',
               'Image'    => 'https://upload.wikimedia.org/wikipedia/id/e/e8/Selena_sampul.jpeg',
               'Year'     => '2020',
               'Publisher'=> 'Penerbit A',
               'Author'  => 'Tere Liye',
               'Synopsis' => 'Buku Selena berlatar di Klan Bulan, menceritakan sosok Selena guru matematika Raib, Seli, dan Ali di Klan Bumi. Kisahnya dimulai saat Selena berusia 15 tahun, menjadi anak yatim piatu karena Ayahnya meninggal, dan kemudian menyusul ibunya, hidup miskin dan tinggal di Distrik Sabit Enam.'
            ],
            [
                'Name'    => 'Autumn in Paris',
                'Image'   => 'https://upload.wikimedia.org/wikipedia/id/6/6b/Autumn_in_Paris.jpg',
                'Year'    => '2007',
                'Publisher'=> 'Penerbit B',
                'Author'  => 'Ilana Tan',
                'Synopsis' => 'Tara Dupont menyukai Paris dan musim gugur. Ia mengira sudah memiliki segalanya dalam hidup… sampai ia bertemu Tatsuya Fujisawa yang susah ditebak dan selalu membangkitkan rasa penasarannya sejak awal.

                Tatsuya Fujisawa benci Paris dan musim gugur. Ia datang ke Paris untuk mencari orang yang menghancurkan hidupnya. Namun ia tidak menduga akan terpesona pada Tara Dupont, gadis yang cerewet tapi bisa menenangkan jiwa dan pikirannya… juga mengubah dunianya.
                
                Tara maupun Tatsuya sama sekali tidak menyadari benang yang menghubungkan mereka dengan masa lalu, adanya rahasia yang menghancurkan segala harapan, perasaan, dan keyakinan. Ketika kebenaran terungkap, tersingkap pula arti putus asa… arti tak berdaya… Kenyataan juga begitu menyakitkan hingga mendorong salah satu dari mereka ingin mengakhiri hidup...'
            ]
            
       
         ];
         return view('BookDetail', compact('Book'));
    }


    public function show(){
        return view('contact');


    }
    public function publish(){
        $Publisher = 
            [
                [
               'Name'     => 'Penerbit A',
               'Address'   => 'Jakarta Selatan',
               'Phone'    => '0869696963',
               'Email'    =>'a@uuuu.com'
                ],
                [
               'Name'     => 'Penerbit B',
               'Address'   => 'Jakarta Selatan',
               'Phone'    => '0869696962',
               'Email'    =>'b@uuuu.com'
                ]
            ];

        return view('publish',compact('Publisher'));


    }

};

