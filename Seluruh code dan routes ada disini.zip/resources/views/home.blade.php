@extends('background')


@section('judul', 'Happy BookStore')

@section('content')

<h1>Book Shelf<span class="badge badge-secondary">New</span></h1>
<div class="container">
<div class="row">
    @foreach($Book as $b)
      <div class="col-md-4 mt-2">
        <div class="card" style="height:100%;">
            <img src="{{ $b['Image'] }}" class="card-img-top" alt="Image"> 
            
            <div class="card-body" >
              <p class="card-title" style="font-size:25px;">{{$b['Name']}}</p>
              <h3>By<h3>
              <p class="card-text">{{$b['Author']}}</p>
              <a class= "btn" href="">Detail</a>


              <!-- <p class="card-text">Synopsis : {{$b['Synopsis']}}</p> -->
              <!-- <p class="card-text">Year : {{$b['Year']}}</p> -->
              
              
              
            

             
            </div>
        
       </div>
      </div>
    @endforeach
</div>
</div>   
@endsection