@extends('background')


@section('judul', 'Happy BookStore')

@section('content')

<div class="container">
<div class="row">
    @foreach($Publisher as $p)

<div class="body" >
              <p class="title" style="font-size:25px;">{{$p['Name']}}</p>
              <p class="text">Address :{{$p['Address']}}</p>
              <p class="text">Phone : {{$p['Phone']}}</p>
              <p class="text">Email : {{$p['Email']}}</p>
              </div>
              @endforeach
        </div>
       </div>
 @endsection