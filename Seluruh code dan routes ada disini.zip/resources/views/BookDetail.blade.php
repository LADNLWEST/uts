@extends('background')


@section('judul', 'Happy BookStore')

@section('content')

<div class="container">
<div class="row">
    @foreach($Book as $b)
<img src="{{ $b['Image'] }}" class="rounded mx-auto d-block" alt="Image"> 
<div class="body" >
              <p class="title" style="font-size:25px;">{{$b['Name']}}</p>
              <p class="text">Author :{{$b['Author']}}</p>
              <p class="text">Publisher : {{$b['Publisher']}}</p>
              <p class="text">Year : {{$b['Year']}}</p>
              <p class="text">Synopsis : {{$b['Synopsis']}}</p> 
              </div>
              @endforeach

              
        </div>
       </div>
 @endsection